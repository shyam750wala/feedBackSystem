import React from 'react'
import Header from '../../components/bar/Header'
import { getAllQuestionnaireBanks } from '../../services/superadmin';
import { useTheme } from '@emotion/react';
import { tokens } from '../../theme';
import { Box } from '@mui/material';
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { useState, useEffect } from 'react';


export default function Index() {


  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchDataFromApi = async () => {
      try {
        const apiData = await getAllQuestionnaireBanks();
        setData(apiData);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchDataFromApi();
  }, []);

  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const columns = [
    { 
      field: "questionnaireBankId", 
      headerName: "ID", 
      flex: 0.2,      //Changed by vanshita on 1-05-2024
    },
    {
      field: "questionnaireBankTitle",
      headerName: "Title",
      flex: 1,
      cellClassName: "name-column--cell",
    },
    { 
      field: 'superAdmin',
      headerName: "SuperAdmin Email ID",
      flex: 0.5,       //Added by vanshita on 1-05-2024
      valueGetter: ( params ) =>  params.emailId
    },
    {
      field: "status",
      headerName: "Status",
      flex: 1,
    },
  ];

  const getRowId = (row) => row.questionnaireBankId;

  return (
    <div>
      <Box m="20px">
      <Header
        title="QuestionnaireBanks"
        subtitle="List of Questionnaires for Feedback Collection"
      />
      <Box
        m="40px 0 0 0"
        height="75vh"
        width="100%"        
        sx={{
          "& .MuiDataGrid-root": {
            border: "none",
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
            fontSize: 14,    //Added by Vanshita on 1-05-2024
          },
          "& .name-column--cell": {
            color: colors.greenAccent[300],
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blueAccent[700],
            borderBottom: "none",
            fontSize: 14,    //Added by Vanshita on 1-05-2024
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.primary[400],
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "none",
            backgroundColor: colors.blueAccent[700],
          },
          "& .MuiCheckbox-root": {
            color: `${colors.greenAccent[200]} !important`,
          },
          "& .MuiDataGrid-toolbarContainer .MuiButton-text": {
            color: `${colors.grey[100]} !important`,
          },
        }}
      >
        <DataGrid
          rows={ data }
          columns={columns}
          components={{ Toolbar: GridToolbar }}
          getRowId={getRowId}
        />
      </Box>
    </Box>
    </div>
  )
}
