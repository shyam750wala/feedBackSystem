import React from 'react'

export default function Dashboard() {
  return (
    <div>
      <h2>Dashboard</h2>
    </div>
  )
}
