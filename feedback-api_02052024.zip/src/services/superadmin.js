import axios from "axios"

const apiURL = "https://localhost:7163/api"

//[GET] Call to fetch QuestionnaireBanks [GET]
export const getAllQuestionnaireBanks = async () =>{
    try {
        const response = await axios.get(`${apiURL}/QuestionnaireBanks`)
        return response.data;
    } catch (error) {
        console.error('Error fetching questionnaire banks :', error);
        throw error;
    }
}