// const baseURL = 'https://localhost:7163/api'

// export {baseURL}